<?php
function acarr(){
    $list = array(
        array(
            'title' =>'财源广进',
            'thumb' =>'https://xcx-album-img.zmwxxcx.com/59415320acc5ade50f5b9dd6e65404f3-thumbnail',
            "bg"=>"https://xcx-album-img.zmwxxcx.com/e94f81e90990b85b513eacac1272d5ec-thumbnail",
            'contnet' => '<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img class="__bg_gif " src="http://mmbiz.qpic.cn/mmbiz_gif/vBKJ934geNLItD1EFYY0Yh4j3FwXTLQtUTgNcGkoqM0ZCViaHPfdoOUiaUiaLudGrzNcU597xAjgFbUNfgkDaicF3g/640?wx_fmt=gif&wxfrom=5&wx_lazy=1" width="auto"/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(84, 255, 159); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">我的亲人朋友们</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(221, 160, 221);"><span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">今天是</strong></span><strong style="color: rgb(255, 251, 0); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important;">8888发发发</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">百年难遇的发财日</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(210, 105, 30); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">最有财祝福送给你</strong></span><span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"> </strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; background-color: rgb(255, 0, 0); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">愿你在2018金狗年</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 251, 0); max-width: 100%; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important;">好运天天有，财运滚滚来</span></strong></span>
</p>
<p style="line-height: 3em; min-height: 1em; max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 251, 0); max-width: 100%; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important;"><br/></span></strong></span>
</p>
<p style="line-height: 3em; min-height: 1em; max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important; text-align: center;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 251, 0); max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important;"></span></strong><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img class="__bg_gif " src="http://mmbiz.qpic.cn/mmbiz_gif/Piam93sUaZwF2e6gSYxhPKh8MguXQfoEHmgFakycXMeDbnJFia1quDm9xXfOwyfZQo8gOaB9UBsg1LPEfaIFibmxQ/640?wx_fmt=gif&wxfrom=5&wx_lazy=1" width="auto"/></strong></span>
</p>
<p style="line-height: 3em; min-height: 1em; max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 251, 0); max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><br/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 110, 180); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">在读微信的那一刹那</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(84, 255, 159); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">祝福开始生效</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(69, 139, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">今天这日子真的牛</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(0, 245, 255); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">为你送去喜禄一大篓</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(219, 112, 147); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">祝你财气冲天不愁钱</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(199, 21, 133); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">上天眷顾你要发就发</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img class="__bg_gif " src="http://mmbiz.qpic.cn/mmbiz_gif/wh4dIX2iablibRFtz6OU4B726hQgDSbaGB2ic0taFBdHWcoIfCoyXqUxsbB5LwhjlOgR7HdXiaBvBlc21d7ICYZvLw/640?wxfrom=5&wx_lazy=1" width="auto"/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">祝愿你<br/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">财源滚滚到你家</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">祥瑞围绕家兴旺</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">生意兴隆钞票抓</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">财气进门金银送</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">全家老少笑哈哈</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">日日盈余生活好</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">发家致富人人夸</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; background-color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">祝你一路发发发<br/>财源滚滚 万事如意</strong></span>
</p>
<p style="line-height: 3em; min-height: 1em; max-width: 100%; word-wrap: break-word !important; box-sizing: border-box !important; text-align: center;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"></strong><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img class="__bg_gif " src="http://mmbiz.qpic.cn/mmbiz_gif/3WOWHfabI6J1Z6DP9WOxXNGDpoXvbIsSXaRfHO5xvaGvn6aqV8tWYQ7YKmlFqs0No4T9gRsjrEwAnFrn5WlXRA/640?wxfrom=5&wx_lazy=1" width="400"/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(192, 255, 62); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">我左看右看上看下看</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">你都是一副发财相啊</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 0, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">我想了又想猜了又猜</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(72, 118, 255); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">终于搞明白</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(127, 255, 170); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">原来是今天是发财日到</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(112, 48, 160); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">那就祝你越来越有财吧</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">天天都愉快</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img class="__bg_gif " src="http://mmbiz.qpic.cn/mmbiz_gif/hV8lO24crrc8wD4NEpWYkWWXpXjvEEpslQW9PtKy5b2zbTdzvDFdpyDkZlmKMiaXD6XWS7jgfcpVK5zShf1q5sw/640?wx_fmt=gif&wxfrom=5&wx_lazy=1" width="auto"/></strong></span>
</p>
<p style="word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <br/>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; background-color: rgb(255, 0, 0); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">发财日</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; background-color: rgb(255, 0, 0); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">一定要送你百财图</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; background-color: rgb(255, 0, 0); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">见者一定发大财的</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img src="http://mmbiz.qpic.cn/mmbiz_png/zicEacHRZicKcicjg1LUn0yelbjPNmqN8XRCsibXMtbyTH4e8icJzF8Jgzj6kfIlzDuT3sydtxBibZEGiaFOmGQSCB8WA/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/><br/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img src="http://mmbiz.qpic.cn/mmbiz_png/zicEacHRZicKcicjg1LUn0yelbjPNmqN8XRvHC1loUu21pzntzWzLHcH2ibg8EIdHDO3NhaVfJwuxVcWIZKc0ibBLtg/640?wx_fmt=gif&wxfrom=5&wx_lazy=1" width="auto"/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; background-color: rgb(255, 0, 0); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 36px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">送你富贵满堂</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; background-color: rgb(255, 0, 0); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 36px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">让你一生富贵</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img src="http://mmbiz.qpic.cn/mmbiz_png/zicEacHRZicKcicjg1LUn0yelbjPNmqN8XRwII23KXzQfk6gpJwHTnGd36XaX6losFOvwX9396IUYWianMXK7b485g/640?wxfrom=5&wx_lazy=1" width="auto"/><br/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img src="http://mmbiz.qpic.cn/mmbiz_png/zicEacHRZicKcicjg1LUn0yelbjPNmqN8XRPvVQKI2OTjic00fBiaqndfvoz6PhmaFF2EywJhFn52bHWQysACjqHWJQ/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/><br/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img src="http://mmbiz.qpic.cn/mmbiz_png/zicEacHRZicKcicjg1LUn0yelbjPNmqN8XRgBMD1piaAe1N4SfFhS6aUfepqvfmoze7Vbj2arAyKFWAo216tnZk5Gw/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/><br/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img src="http://mmbiz.qpic.cn/mmbiz_png/zicEacHRZicKcicjg1LUn0yelbjPNmqN8XRP1tHGn6tqWcYh7zoeTaglUYgJicefpHPUXpMuxmCSF1ebeQicSryl4qw/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/><br/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="color: rgb(255, 251, 0); max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;"><img src="http://mmbiz.qpic.cn/mmbiz_png/zicEacHRZicKcicjg1LUn0yelbjPNmqN8XRwg1VJNTibd41O7sjamHI2ibheNKcgicDMTaiaUiaugWic5gPfnAWaf6qHFZA/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/></strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 0, 0); background-color: rgb(255, 255, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">财神爷说了：</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 0, 0); background-color: rgb(255, 255, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">今天谁会把这祝福</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 0, 0); background-color: rgb(255, 255, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">给家人和朋友送上</strong></span>
</p>
<p style="text-align: center; line-height: 3em; word-wrap: break-word !important; min-height: 1em; max-width: 100%; box-sizing: border-box !important;">
    <span style="max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 0, 0); background-color: rgb(255, 255, 0); word-wrap: break-word !important; box-sizing: border-box !important;"><strong style="word-wrap: break-word !important; max-width: 100%; box-sizing: border-box !important;">今年一定發發發！</strong></span>
</p>
<p>
    <br/>
</p>',),
        array(
            'title' =>'福星高照',
            'thumb' =>'https://xcx-album-img.zmwxxcx.com/7ba478c8f1f4871ab296f7862d822b0a-thumbnail',
            "bg"=>"https://xcx-album-img.duomai.com/83a1798546922be0fdf672519f67de0d",
            'contnet' => '<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"><img class=" __bg_gif" src="http://mmbiz.qpic.cn/mmbiz_gif/VcWJXHQg6GgVibcxTibvmDueT6IXqvYtfQemroPbh6VfWH0cUJ90o5RgOQXbmib70LsERFzXMuwLnkATliaqJuLJ8w/640?wx_fmt=gif&wxfrom=5&wx_lazy=1"/></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"></span></strong></span>
</p>
<p style="margin-top: 5px; margin-bottom: 5px; line-height: 2em;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; color: rgb(255, 255, 0); background-color: rgb(0, 176, 80);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 36px;"></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(191, 239, 255);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"><br/></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; margin-top: 5px; line-height: 2em; text-align: center; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(191, 239, 255);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">九九同心长久日</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 192, 0);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">久久祝福送给你</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(84, 255, 159);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">愿这份长长久久</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(84, 255, 159);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">把好意头伴随你</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 255, 0);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">过不完的幸福日子</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(0, 176, 80);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">赚不完的人民票子</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(0, 176, 240);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">数不尽的快乐时刻</span></strong></span>
</p>
<p style="text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em;">
    <img src="http://mmbiz.qpic.cn/mmbiz_gif/Pic6KsA3icC888I2awnTCdQARL2Ctddo9RTu7fch13IRY5Svdjy8zGzQXkQN8Jr24hzjn4jQ8UUtQNnI1hwJyuFQ/640?wx_fmt=gif&wxfrom=5&wx_lazy=1"/>
</p>
<p style="text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; text-align: center; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"><strong style="color: rgb(192, 255, 62); font-size: 16px; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">取好运久久之水</span></strong></span></strong></span>
</p>
<p style="text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px;">
    <strong style="color: rgb(255, 62, 150); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; text-align: center; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">摘平安久久之花</span></strong>
</p>
<p style="text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px;">
    <strong style="color: rgb(127, 255, 170); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; text-align: center; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">点快乐久久之火</span></strong>
</p>
<p style="text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px;">
    <strong style="color: rgb(112, 48, 160); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; text-align: center; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">为你酿一坛友情久久之酒</span></strong>
</p>
<p style="text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px;">
    <strong style="color: rgb(146, 208, 80); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; text-align: center; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">盛在这祝福久久的短信里</span></strong>
</p>
<p style="text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px;">
    <strong style="color: rgb(0, 176, 240); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; text-align: center; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">愿你能畅享幸福久久之味</span></strong>
</p>
<p style="margin-top: 5px; margin-bottom: 5px; line-height: 2em;">
    <strong style="color: rgb(0, 176, 240); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; text-align: center; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"><br/></span></strong>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(96, 127, 166); text-decoration: none; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 0px; display: inline-block;"><a href="http://mp.weixin.qq.com/s?__biz=MzA4MzQwNTE2MQ==&mid=2649868702&idx=2&sn=96e99b8ddb1ec9eece6eb7a374542ee8&chksm=87f39998b084108e02122daf0f1e42533c4e4531f18940b35d44c60090380a64a5ed7eed9585&scene=21#wechat_redirect" target="_blank" style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; color: rgb(96, 127, 166); text-decoration: none;"><img class="__bg_gif" src="http://mmbiz.qpic.cn/mmbiz_gif/hV8lO24crreEYfysz0aOMZK9hkcpic6qJ3XJLTkSYg2rrkeBQeFzalVcoKBAZicq2akOy86y5NMfhvzpHQf0EibGA/640?wx_fmt=gif&wxfrom=5&wx_lazy=1" width="auto"/></a></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; text-align: center; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 105, 180); box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">祝福短信请接收</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 192, 0);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">祝你天天开笑口</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; color: rgb(146, 208, 80);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">烦恼没有幸福留</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(0, 176, 80);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">工作轻松假常休</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 62, 150);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">生活更上一层楼</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(0, 176, 240);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">家庭美满有奔头</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; white-space: normal; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(0, 112, 192);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">爱情天长又地久</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(0, 112, 192);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"><br/></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(0, 112, 192);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"><strong style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 112, 192); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; text-align: center; white-space: normal; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 0px; display: inline-block;"><a href="http://mp.weixin.qq.com/s?__biz=MzA4MzQwNTE2MQ==&mid=2649868702&idx=2&sn=96e99b8ddb1ec9eece6eb7a374542ee8&chksm=87f39998b084108e02122daf0f1e42533c4e4531f18940b35d44c60090380a64a5ed7eed9585&scene=21#wechat_redirect" target="_blank" style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; color: rgb(96, 127, 166); text-decoration: none;"><img class="__bg_gif" src="http://mmbiz.qpic.cn/mmbiz_gif/hV8lO24crreEYfysz0aOMZK9hkcpic6qJzZez4NkwgKTY0eZc1ibic4RfujlhRYKlvl3WIGxJSxcm2LnUseQtNLHg/640?wx_fmt=gif&wxfrom=5&wx_lazy=1" width="auto"/></a></span></strong></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(0, 112, 192);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"><strong style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 112, 192); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; text-align: center; white-space: normal; box-sizing: border-box !important; word-wrap: break-word !important;"><br/></strong></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(112, 48, 160);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">朋友，想一想，念一念</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(192, 255, 62);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">祝福，写一写，发一发</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 62, 150);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">犹如清新的小雨</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(238, 238, 0);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">洗去你心头的烦忧</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(238, 238, 0);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">像凉爽的凉风</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 0, 0);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">吹开你紧锁的眉头</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 0, 0);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; font-size: 0px; font-weight: 400; display: inline-block; box-sizing: border-box !important; word-wrap: break-word !important;"><a href="http://mp.weixin.qq.com/s?__biz=MzA4MzQwNTE2MQ==&mid=2649868702&idx=2&sn=96e99b8ddb1ec9eece6eb7a374542ee8&chksm=87f39998b084108e02122daf0f1e42533c4e4531f18940b35d44c60090380a64a5ed7eed9585&scene=21#wechat_redirect" target="_blank" style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; color: rgb(96, 127, 166); text-decoration: none;"><img class="__bg_gif" src="http://mmbiz.qpic.cn/mmbiz_gif/hV8lO24crreEYfysz0aOMZK9hkcpic6qJZ0oE9648MrbG2pGY0BJ3sKupEtyiaA8aFhDOpfF58mFbiaCX9IcicMfbQ/640?wx_fmt=gif&wxfrom=5&wx_lazy=1" width="auto"/></a></span></strong>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 192, 0); box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"><br/></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 192, 0); box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">快乐说我要永久的跟着你</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <strong style="color: rgb(255, 255, 0); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">健康说我要永久的属于你</span></strong>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <strong style="color: rgb(255, 0, 0); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">平安说我要永久的随着你</span></strong>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <strong style="color: rgb(0, 176, 80); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">吉祥说我要永久的缠着你</span></strong>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <strong style="color: rgb(0, 176, 240); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">财神说我要永久的关照你</span></strong>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <strong style="color: rgb(112, 48, 160); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">愿你永久的开心</span></strong>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; line-height: 2em; margin-bottom: 15px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <strong style="color: rgb(112, 48, 160); font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;">永久的快乐</span></strong>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 0, 0);"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; font-size: 24px;"></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " src="http://mmbiz.qpic.cn/mmbiz_gif/hV8lO24crrdG4aicKRmZRzcGWdWLsPDXMOs0kGc3vFbwUrfPQ7Vk55LOHSXANWeFLZ0W7qEibLOdicSibkAskwMqKQ/640?wx_fmt=gif&wxfrom=5&wx_lazy=1" width="auto"/><br/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " src="http://mmbiz.qpic.cn/mmbiz_gif/hV8lO24crrcQvH8mGN3ogG6lDtntUg3GdgDOFyd6ATmtB1icxibXHOic1D1Ab7GAkkYEL1EO0dOHewF1v3DS7EKuA/640?wx_fmt=gif&wxfrom=5&wx_lazy=1" width="auto"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>
<p style="text-align: center;">
    <strong><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 36px; background-color: rgb(255, 255, 0); color: rgb(255, 0, 0);">送你99朵祝福花</span></strong>
</p>
<p style="text-align: center;">
    <strong><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 36px; background-color: rgb(255, 255, 0); color: rgb(255, 0, 0);">愿你有好运久久</span></strong>
</p>
<p>
    <br/>
</p>
<p>
    <br/>
</p>
<p>
</p>
<section><section><section>
    <p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
        <img src="http://mmbiz.qpic.cn/mmbiz_png/CHCgyYxvzwQ3Yhp2HhHjS4kZeYhjwOiaDXsEwgUmh9wxhibYZ5kI2qq3oEeSv3vMqZKLubExWmyT34bHLhyicGZ6w/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/>
    </p>
    <p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
        <img src="http://mmbiz.qpic.cn/mmbiz_png/CHCgyYxvzwQ3Yhp2HhHjS4kZeYhjwOiaD7Uc07Z7RIiaYO7sALR0sLhicTKribhHasVclvicbGrY4ibaz8IDeMguIlMA/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/>
    </p>
    <p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
        <img src="http://mmbiz.qpic.cn/mmbiz_png/CHCgyYxvzwQ3Yhp2HhHjS4kZeYhjwOiaDVaTia8bKJMAIQiaJ0rzU2ibVXMAMXj9iae88AA8RAy1vrdJFrrKRYYdgnA/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/>
    </p>
    <p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
        <img src="http://mmbiz.qpic.cn/mmbiz_png/CHCgyYxvzwQ3Yhp2HhHjS4kZeYhjwOiaDQeEciaoz7uQ727kJogTsrib1KCUoATmYUF9MmmG1k64eCw2msXAj6tMw/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/>
    </p>
</section></section></section><section><section><section>
    <p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
        <img src="http://mmbiz.qpic.cn/mmbiz_png/CHCgyYxvzwQ3Yhp2HhHjS4kZeYhjwOiaDEib81KqZ1Gu5BU8N76uQPwaicz0UDQ7fiacoS6rFVSOLtu6mxGZK8fHRQ/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/>
    </p>
</section></section></section>
<p>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img src="http://mmbiz.qpic.cn/mmbiz_png/CHCgyYxvzwQ3Yhp2HhHjS4kZeYhjwOiaD48NicPtd5LNLGicv2565k1Vzo0zZJ695jvWfl6FYuuAHuhdZJITaoGrw/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img src="http://mmbiz.qpic.cn/mmbiz_png/CHCgyYxvzwQ3Yhp2HhHjS4kZeYhjwOiaDZ31BP0Oc1IawZR4B1W3ib5BEYicpl3KhhgL9dwbLpADdm2M0gRbZv7Tg/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img src="http://mmbiz.qpic.cn/mmbiz_png/CHCgyYxvzwQ3Yhp2HhHjS4kZeYhjwOiaDF4B1eT2S47z1uFCPibx9AfplmJfR2o37Pia2YqyvWdKaslNtLp2MSTJg/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img src="http://mmbiz.qpic.cn/mmbiz_png/CHCgyYxvzwQ3Yhp2HhHjS4kZeYhjwOiaDliaJupmGGEUQ9h2yu4Lpo8AfgjMEWRjaqvkicO447LSusEnCicyBWjvSA/640?wx_fmt=png&wxfrom=5&wx_lazy=1" width="auto"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>
<p>
    <span style="color: rgb(255, 255, 0); background-color: rgb(255, 0, 0);"><strong><span style="font-size: 36px;"><br/></span></strong></span>
</p>
<p style="white-space: normal; line-height: 2em;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 255, 0); background-color: rgb(0, 176, 80); box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="margin: 0px; padding: 0px; max-width: 100%; font-size: 36px; box-sizing: border-box !important; word-wrap: break-word !important;"></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>'
        ),array(
            'title' =>'财源滚滚',
            'thumb' =>'https://xcx-album-img.duomai.com/FjyqkSiF_3pwYSoTryVwpYAY4-_Y-thumbnail',
            "bg"=>"https://xcx-album-img.duomai.com/FvOptJ1WBSSjSAzvUgqoF4j2qqry",
            'contnet' => '<p style="text-align: center;">
    <img src="https://xcx-album-img.duomai.com/FpS2aQv-b_dpO36asPCIkop2AyTi" title="640 (6).gif" alt="640 (6).gif"/><br/>
</p>
<p style="text-align: center;">
    <br/>
</p>
<p style="text-align: center;">
    <span style="font-size: 24px; text-decoration: none; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(0, 0, 0);"><strong>八八八，</strong></span><span style="font-size: 24px; text-decoration: none; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(192, 255, 62);"><strong>发发发</strong></span>
</p>
<p>
    <span style="color: rgb(255, 255, 0); font-size: 24px; text-decoration: none;"></span>
</p>
<p style="margin-top: 0px; color: rgb(255, 255, 255); font-family: 微软雅黑; font-weight: bold; white-space: normal; padding: 0px; max-width: 100%; clear: both; min-height: 1em; text-align: center; line-height: 2em; margin-bottom: 10px; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; text-decoration: none; color: rgb(255, 192, 0);"><strong></strong></span><span style="color: rgb(255, 0, 0); font-size: 24px; text-decoration: none;"><strong><span style="font-size: 24px; text-decoration: none; color: rgb(0, 176, 240);">祝你</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em; margin-bottom: 10px;">
    <span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 255, 0);"><strong>财源滚滚来</strong></span>
</p>
<p style="text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Ft3uGUFm98j23AW7apu1OZFh12tp" title="0 (1).gif" alt="0 (1).gif"/>
</p>
<p style="text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Fk3fy1o2_A91lRKSL8rv_qvfrus6" title="0HJNalqXXbk.jpg" alt="0HJNalqXXbk.jpg"/>
</p>
<p>
    <br/>
</p>
<p style="white-space: normal; text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Foc9-U5I-3otFQrlT-0O09LnseHy" title="0 (2).gif" alt="0 (2).gif"/>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 0, 0);"><strong>排排摇钱树，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 192, 0);"><strong><span style="font-size: 24px;">开出富贵花，</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 255, 0);"><strong>长出发财果，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(146, 208, 80);"><strong>结出财运籽，</strong></span><span style="font-size: 24px;"><span style="color: rgb(255, 192, 0);"></span><span style="color: rgb(84, 141, 212);"><strong><span style="color: rgb(84, 141, 212);"></span></strong><strong><span style="color: rgb(84, 141, 212);"></span></strong></span></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 176, 80);"><strong>再生幸福芽，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 176, 240);"><strong>一生财路广，</strong></span><span style="font-size: 24px;"><span style="color: rgb(146, 208, 80);"></span><span style="color: rgb(149, 55, 52);"><strong><span style="color: rgb(149, 55, 52);"></span></strong><strong><span style="color: rgb(149, 55, 52);"></span></strong><strong><span style="color: rgb(149, 55, 52);"></span></strong><strong><span style="color: rgb(149, 55, 52);"></span></strong></span></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 245, 255);"><strong>万事财气生，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(209, 95, 238);"><strong>愿你财源亨通，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 62, 150);"><strong>万事发发发！</strong></span>
</p>
<p>
    <br/>
</p>
<p style="text-align: center;">
    <img src="https://xcx-album-img.duomai.com/FqGAV1tQYQ8wasPZw3I61kSuJkVZ" title="a7yh1q42436803319405.gif" alt="a7yh1q42436803319405.gif"/>
</p>
<p>
    <br/>
</p>
<p style="white-space: normal; text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Foc9-U5I-3otFQrlT-0O09LnseHy" title="0 (2).gif" alt="0 (2).gif"/>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 62, 150);"><strong>八八八，</strong></span><span style="font-size: 24px; color: rgb(112, 48, 160);"><strong>发发发。</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(209, 95, 238);"><strong>送给你我他，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 238, 238);"><strong><span style="font-size: 24px;">祝福大家</span></strong></span><span style="font-size: 24px; color: rgb(0, 112, 192);"><strong><span style="font-size: 24px;">永远发。</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(64, 224, 208);"><strong>幸福快乐</strong></span><span style="font-size: 24px; color: rgb(0, 176, 80);"><strong>满把抓，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 255, 0);"><strong>财神已经</strong></span><span style="font-size: 24px; color: rgb(146, 208, 80);"><strong>到你家。</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 0, 0);"><strong>从此生活</strong></span><span style="color: rgb(255, 192, 0); font-size: 24px;"><strong><span style="color: rgb(255, 192, 0);">幸福<span style="font-size: 24px; color: rgb(192, 255, 62);">笑哈哈。</span></span></strong></span>
</p>
<p>
    <br/>
</p>
<p style="text-align: center;">
    <img src="https://xcx-album-img.duomai.com/FuJNF339WP4SUWDLJ4eOyEXNHAKU" title="ee36cf6agw1f0m1l0pj23g20bo064wgx.gif" alt="ee36cf6agw1f0m1l0pj23g20bo064wgx.gif"/>
</p>
<p>
    <br/>
</p>
<p style="white-space: normal; text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Foc9-U5I-3otFQrlT-0O09LnseHy" title="0 (2).gif" alt="0 (2).gif"/>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 0, 0);"><strong>送你一座金山，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="color: rgb(255, 255, 0); font-size: 24px;"><strong><span style="color: rgb(255, 255, 0);">愿你财源不断；</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 192, 0);"><strong><span style="font-size: 24px;">送你一条金路，</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="color: rgb(146, 208, 80); font-size: 24px;"><strong><span style="color: rgb(146, 208, 80);">愿你青云平步；</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 176, 80);"><strong><span style="font-size: 24px;">送你一张金床，</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="color: rgb(0, 176, 240); font-size: 24px;"><strong><span style="color: rgb(0, 176, 240);">愿你舒适无上；</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 112, 192);"><strong>送你一条金鱼，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(112, 48, 160);"><strong>愿你快乐无限。</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 62, 150);"><strong>财源广进，快乐无限！</strong></span>
</p>
<p>
    <br/>
</p>
<p style="text-align: center;">
    <img src="https://xcx-album-img.duomai.com/FklfWLtAsZobpsXYwzlqoGCYZdMO" title="timg (1).gif" alt="timg (1).gif"/>
</p>
<p>
    <br/>
</p>
<p style="white-space: normal; text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Foc9-U5I-3otFQrlT-0O09LnseHy" title="0 (2).gif" alt="0 (2).gif"/>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 0, 0);"><strong>鞭炮齐鸣</strong></span><span style="font-size: 24px; color: rgb(255, 192, 0);"><strong><span style="font-size: 24px;">发大财，</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 255, 0);"><strong>汽车别墅</strong></span><span style="font-size: 24px; color: rgb(146, 208, 80);"><strong>不能少，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 176, 80);"><strong>好运跟着</strong></span><span style="font-size: 24px; color: rgb(0, 176, 240);"><strong>凑热闹，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 238, 238);"><strong><span style="font-size: 24px;">白银黄金</span></strong></span><span style="font-size: 24px; color: rgb(209, 95, 238);"><strong><span style="font-size: 24px;">装满袋，</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(112, 48, 160);"><strong><span style="font-size: 24px;">红红钞票</span></strong></span><span style="font-size: 24px; color: rgb(255, 110, 180);"><strong><span style="font-size: 24px;">数不完，</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 62, 150);"><strong><span style="font-size: 24px;">万事都愉快，</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(192, 0, 0);"><strong><span style="font-size: 24px;">眉开又眼笑，</span></strong></span><span style="font-size: 24px; color: rgb(0, 0, 255);"><strong><span style="font-size: 24px;">得意乐开怀！</span></strong></span>
</p>
<p>
    <br/>
</p>
<p style="text-align: center;">
    <img src="https://xcx-album-img.duomai.com/FhCvk8YYFavqsaie8lIMfS4Q363t" title="88c833630ae94fab8395f8d7834b8242.gif" alt="88c833630ae94fab8395f8d7834b8242.gif" width="706" height="405"/>
</p>
<p>
    <br/>
</p>
<p style="white-space: normal; text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Foc9-U5I-3otFQrlT-0O09LnseHy" title="0 (2).gif" alt="0 (2).gif"/>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 0, 0);"><strong>向快乐出发，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 192, 0);"><strong>向吉祥出发，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="color: rgb(255, 255, 0); font-size: 24px;"><strong>向如意出发，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(146, 208, 80);"><strong>向甜蜜出发，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(0, 176, 240);"><strong>向顺利出发，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(209, 95, 238);"><strong>向成功出发，</strong></span>
</p>
<p style="text-align: center; line-height: 2em;">
    <span style="font-size: 24px; color: rgb(255, 62, 150);"><strong>向幸福出发！</strong></span>
</p>
<p>
    <br/>
</p>
<p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-family: 宋体, arial, sans-serif; font-size: 12px; white-space: normal; text-align: center;">
    <span style="font-size: 18px;"><img src="https://xcx-album-img.duomai.com/Fhe52TxeSNZ5wIDy08vasIlhcX1K" title="d5077562583c91bf6a43198e1ca27c8e.gif" alt="d5077562583c91bf6a43198e1ca27c8e.gif"/></span>
</p>
<p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-family: 宋体, arial, sans-serif; font-size: 12px; white-space: normal; ">
    <span style="font-size: 18px;">&nbsp;</span><br/>
</p>
<p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; font-family: 宋体, arial, sans-serif; font-size: 12px; white-space: normal; ">
    <span style="font-size: 18px;"></span>
</p>
<p style="text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Foc9-U5I-3otFQrlT-0O09LnseHy" title="0 (2).gif" alt="0 (2).gif"/>
</p>
<p style="text-align: center; line-height: 2em; margin-bottom: 10px;">
    <span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(0, 0, 0);"><strong>天空彩旗沸腾，</strong></span>
</p>
<p style="text-align: center; line-height: 2em; margin-bottom: 10px;">
    <span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 192, 0);"><strong>火红的事业</strong></span><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 255, 0);"><strong>财源广进，</strong></span>
</p>
<p style="text-align: center; line-height: 2em; margin-bottom: 10px;">
    <span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(146, 208, 80);"><strong>温馨的</strong></span><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(0, 176, 80);"><strong>祝愿</strong></span><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(192, 255, 62);"><strong>繁荣昌隆，</strong></span>
</p>
<p style="text-align: center; line-height: 2em; margin-bottom: 10px;">
    <span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(0, 176, 240);"><strong>真诚的祝福</strong></span><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(0, 245, 255);"><strong>带动着跳跃</strong></span><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(0, 0, 255);"><strong>的音符，</strong></span>
</p>
<p style="text-align: center; line-height: 2em; margin-bottom: 10px;">
    <span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(112, 48, 160);"><strong>为您带去</strong></span><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(209, 95, 238);"><strong>春的生机，</strong></span>
</p>
<p style="text-align: center; line-height: 2em; margin-bottom: 10px;">
    <span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 62, 150);"><strong>在这美好<span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(255, 130, 171);">的日子里，</span></strong></span>
</p>
<p style="text-align: center; line-height: 2em; margin-bottom: 10px;">
    <span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px; color: rgb(0, 0, 0);"><strong>万事如意！</strong></span>
</p>
<p>
    <br/>
</p>
<p style="text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Fs1LIRDIBO7jJvpAzsNCqP_0a6fW" title="timgsdgsgf.gif" alt="timgsdgsgf.gif"/>
</p>
<p>
    <br/>
</p>
<p style="white-space: normal; text-align: center;">
    <img src="https://xcx-album-img.duomai.com/Foc9-U5I-3otFQrlT-0O09LnseHy" title="0 (2).gif" alt="0 (2).gif"/>
</p>
<p style="text-align: center;">
    <span style="font-size: 24px; color: rgb(0, 0, 0);"><strong><span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;">愿你抱</span></strong></span><span style="font-size: 24px; color: rgb(255, 192, 0);"><strong><span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;">着平安，</span></strong></span>
</p>
<p style="margin-top: 0px; padding: 0px; font-family: 宋体, arial, sans-serif; font-size: 12px; white-space: normal; text-align: center; line-height: 2em; margin-bottom: 5px;">
    <span style="color: rgb(0, 176, 80);"><strong><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; font-size: 24px;">拥着健康，</span></strong></span><strong><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 255, 0); font-size: 24px;">揣着幸福，</span></strong>
</p>
<p style="margin-top: 0px; padding: 0px; font-family: 宋体, arial, sans-serif; font-size: 12px; white-space: normal; text-align: center; line-height: 2em; margin-bottom: 5px;">
    <span style="color: rgb(0, 176, 240);"><strong><span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;">携着快乐，</span></strong></span><strong><span style="color: rgb(146, 208, 80); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;">搂着温馨，</span></strong>
</p>
<p style="margin-top: 0px; padding: 0px; font-family: 宋体, arial, sans-serif; font-size: 12px; white-space: normal; text-align: center; line-height: 2em; margin-bottom: 5px;">
    <strong><span style="color: rgb(0, 176, 240); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;">带着甜蜜，<span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(209, 95, 238);">牵着财运，</span></span></strong>
</p>
<p style="margin-top: 0px; padding: 0px; font-family: 宋体, arial, sans-serif; font-size: 12px; white-space: normal; text-align: center; line-height: 2em; margin-bottom: 10px;">
    <strong><span style="color: rgb(112, 48, 160); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;">拽着吉祥<span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(255, 62, 150);">，迈入新年，</span></span></strong>
</p>
<p style="text-align: center;">
    <span style="font-size: 24px; color: rgb(209, 95, 238);"><strong><span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;">快乐<span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; color: rgb(108, 166, 205);">度过每一天！</span></span></strong></span>
</p>'
        ),array(
            'title' =>'六六大顺',
            'thumb' =>'https://xcx-album-img.zmwxxcx.com/901c298e89d26a92f2ee31d365ddd082-thumbnail',
            "bg"=>"https://xcx-album-img.zmwxxcx.com/ffe50cd3a5a0d47383c71314f092d13b-thumbnail",
            'contnet' => '<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="font-size: 36px; font-family: Simsun; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-size: 24px; margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 251, 0); box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; line-height: 25.6px; white-space: normal;"><span style="font-size: 24px; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"></span></strong></span></strong><strong style="font-size: 36px; font-family: Simsun; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-size: 24px; margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 251, 0); box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; line-height: 25.6px; white-space: normal;"><span style="font-size: 24px; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><img class="__bg_gif " width="auto" src="https://mmbiz.qpic.cn/mmbiz/1NRKgdUaESzdu977srPlQ97KvrjOBMa5amSoCUHZyia1w2Iqzgias6fyMgsfIATjNcAibxic5ym3AiackicZsrECsGQA/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/></span></strong></span></strong></span><br/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="font-size: 36px; font-family: Simsun; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-size: 24px; margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 251, 0); box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important; line-height: 25.6px; white-space: normal;"><span style="font-size: 24px; margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"></span></strong></span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 251, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">祝你万事都顺：</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 252, 255); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">业绩骄人，事业顺；</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 41, 65); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">牵手佳人，爱情顺；</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(172, 57, 255); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">做个牛人，生活顺；</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(115, 250, 121); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">相伴贵人，友情顺；</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(120, 172, 254); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">总遇好人，出门顺；</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 79, 121); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">加薪喜人，财运顺！</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " width="auto" src="https://mmbiz.qpic.cn/mmbiz/wh4dIX2iablicVic5mKCuv0Wibnfqat1NdtUaX2LPp1z0rPU6VmjQjk1JjJU3BN7ZrJ1rreg2UGNQa5MU7nMy8oglw/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(216, 79, 169); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">万事皆顺日，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(115, 252, 214); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">在这开心的日子里，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 209, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">祝愿你，事业，如日中天，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 127, 170); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">健康，一尘不染，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 169, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">生意，一本万利，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(215, 171, 169); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">旅途，一路顺风，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(212, 250, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">总之，祝你在新的一年里，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 41, 65); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">一切皆顺。</strong></span>
</p>
<p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 41, 65); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 251, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">万事顺意日，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(115, 250, 121); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">在这大吉的日子里，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(115, 252, 214); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">祝愿你，把身体理顺，健康幸福，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 172, 213); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">把事情理顺，轻松美妙，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 79, 121); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">把心情理顺，绽放微笑，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 169, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">把日子理顺，少些争吵，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 41, 65); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">总之，祝你在新的一年里，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(172, 57, 255); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">心顺手顺万事顺，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(216, 79, 169); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">家顺业顺一路顺。</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 251, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " title="http://7xo6kd.com1.z0.glb.clouddn.com/upload-ueditor-image-20160916-1473975466829053468.gif" width="auto" src="https://mmbiz.qpic.cn/mmbiz_gif/baCyfL2I52RTMzicZ3UGicrk8ChpotYWxWkPTDY3yPnyPRtQ1iaia1yKH7sWdbjXUo5WhYFjmsXoO9UOFVft7OCu9Q/640?tp=webp&wxfrom=5&wx_lazy=1"/>
</p>
<p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 251, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">开门六福降临：</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 79, 121); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">福星高照，福缘深厚，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 252, 255); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">福禄双全，福如东海，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 104, 39); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">福纳百祥，福气冲天！</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 209, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">六福连连送给你，</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(216, 79, 169); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">好运天天溜溜溜！&nbsp;</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " width="auto" src="https://mmbiz.qpic.cn/mmbiz/hV8lO24crrdt7frciaBXlvrP4TuLFGKPdqUx9PltHgoKPxwozM7OFKrZzTLOYDg5rQ8a8ABHN7v0csbicNG5KFLQ/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 20px; color: rgb(255, 251, 0); box-sizing: border-box !important; word-wrap: break-word !important;">祝你财顺，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 252, 255); font-size: 20px; box-sizing: border-box !important; word-wrap: break-word !important;">金银珠宝一筐筐，钱元银元无尽享；</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 20px; color: rgb(216, 79, 169); box-sizing: border-box !important; word-wrap: break-word !important;">祝你命顺，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 20px; color: rgb(0, 209, 0); box-sizing: border-box !important; word-wrap: break-word !important;">吉祥如意日子旺，大吉大利岁月长；</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 20px; color: rgb(214, 168, 65); box-sizing: border-box !important; word-wrap: break-word !important;">祝你体顺，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 20px; color: rgb(0, 82, 255); box-sizing: border-box !important; word-wrap: break-word !important;">平安长久身强壮，福寿无边保安康；</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 20px; color: rgb(255, 104, 39); box-sizing: border-box !important; word-wrap: break-word !important;">祝你运顺，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 20px; color: rgb(217, 33, 66); box-sizing: border-box !important; word-wrap: break-word !important;">好事美事皆成双，幸福美满福运淌。</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " width="auto" src="https://mmbiz.qpic.cn/mmbiz/Z7xQXHJf7AISvQgLrQsyTdOAveWSicVyqicoeFSNPCoutic4ibUscz16uV8TRviccEQ6icGPLusjaXB67DicicgtNHc3yg/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/><span style="margin: 0px; padding: 0px; max-width: 100%; color: rgba(0, 0, 0, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 24px; color: rgb(255, 251, 0); box-sizing: border-box !important; word-wrap: break-word !important;">六六大顺，要顺要顺</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(115, 250, 121); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;">把身体理顺，健康安好</span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 252, 255); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;">把事情理顺，轻松美妙</span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(120, 172, 254); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;">把心情理顺，绽放微笑</span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(216, 79, 169); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;">把日子理顺，少些吵闹</span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 41, 65); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;">今天，愿你</span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(172, 57, 255); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;">把生活调顺，把人生理顺</span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 128, 255); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;">一帆风顺</span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 213, 255); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;">心顺手顺万事顺</span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; font-weight: bold; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(0, 209, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;">家顺业顺一路顺</span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " width="auto" src="https://mmbiz.qpic.cn/mmbiz/Yz0S2gt7icqxbLNqexMy67Ar9zUswibGxkYw0PKWJJicwNzHCQaXDglhtXDyiaphg0QSWcO3RZpTicHo1mR7LuQ5L2w/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 24px; color: rgb(255, 251, 0); box-sizing: border-box !important; word-wrap: break-word !important;">1帆风顺春日吉，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 24px; color: rgb(216, 79, 169); box-sizing: border-box !important; word-wrap: break-word !important;">2龙腾飞夏日续，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 24px; color: rgb(0, 252, 255); box-sizing: border-box !important; word-wrap: break-word !important;">3言两语福花齐，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 24px; color: rgb(115, 250, 121); box-sizing: border-box !important; word-wrap: break-word !important;">4季平安祥雨聚，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 24px; color: rgb(255, 41, 65); box-sizing: border-box !important; word-wrap: break-word !important;">5彩生活甜如蜜，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: pre-wrap; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><span style="font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; margin: 0px; padding: 0px; max-width: 100%; font-size: 24px; color: rgb(216, 79, 169); box-sizing: border-box !important; word-wrap: break-word !important;">6六大顺事业喜，</span></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 0, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;">祝你万事顺心夏日里。</strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <span style="margin: 0px; padding: 0px; max-width: 100%; color: rgb(255, 0, 0); font-size: 24px; font-family: 微软雅黑, &quot;Microsoft YaHei&quot;; box-sizing: border-box !important; word-wrap: break-word !important;"><strong style="margin: 0px; padding: 0px; max-width: 100%; box-sizing: border-box !important; word-wrap: break-word !important;"><br/></strong></span>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " src="https://mmbiz.qpic.cn/mmbiz_gif/Piam93sUaZwG07jvJaiaajqFMeEnVwfnVfH0QIKUstYJVjcBPclxd3ljwtAElny5hL87jIbLDP65Zj2jclIPgqiaw/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " src="https://mmbiz.qpic.cn/mmbiz_gif/Piam93sUaZwG07jvJaiaajqFMeEnVwfnVfB8Kr6Via8hBcAWPOET7y2IAkUOneLf7mhpofjP1Jrld9QXZGS9OfMiaA/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " src="https://mmbiz.qpic.cn/mmbiz_gif/Piam93sUaZwG07jvJaiaajqFMeEnVwfnVfpdSlYNhF2PhSuCzreqGdMrBn7AO8DbteMgvoF9VUibibGibCL34mlksWQ/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " src="https://mmbiz.qpic.cn/mmbiz_gif/Piam93sUaZwG07jvJaiaajqFMeEnVwfnVfo0Jal57EDuxmugnX2I1icrN8Ipgh3veOn3hZVGVZtqCU9C5wibofnj3g/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; text-align: center; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <img class="__bg_gif " src="https://mmbiz.qpic.cn/mmbiz_gif/Piam93sUaZwG07jvJaiaajqFMeEnVwfnVf4f7cAaEy3ic8b4oiaBUEicsJU8cBtia0AFyU1EBibEH1s2LxJDaf4oGwTRw/640?wx_fmt=gif&tp=webp&wxfrom=5&wx_lazy=1"/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>
<p style="padding: 0px; max-width: 100%; clear: both; min-height: 1em; color: rgb(62, 62, 62); font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; white-space: normal; margin-top: 5px; margin-bottom: 5px; line-height: 2em; box-sizing: border-box !important; word-wrap: break-word !important;">
    <br/>
</p>'
        ),array(
            'title' =>'福寿绵长',
            'thumb' =>'https://qqwin.shanweifang.com.cn/static/upload/article/20180225092719_411.png',
            "bg"=>"https://file.gesmen.com.cn/bg/1.gif",
            'contnet' => '<p>
	<span style="color:#E53333;font-size:32px;"><br />
</span> 
</p>
<p>
	<span style="color:#E53333;font-size:48px;">长寿日到了</span> 
</p>
<p>
	<span style="color:#E53333;font-size:32px;"><span style="font-size:48px;color:#FF9900;">把这份长寿祝福送给你</span><br />
福寿绵长活百岁<br />
身体健康行如风</span> 
</p>
<p>
	<span style="color:#E53333;font-size:32px;"><br />
</span> 
</p>
<p>
	<span style="color:#E53333;font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224192233_289.gif" title="20180224192233_289.gif" alt="20180224192233_289.gif" /><br />
<br />
</span> 
</p>
<p>
	<br />
</p>
<p>
	<span style="color:#E53333;font-size:32px;"><span style="color:#00D5FF;">长寿日，祝福到</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#00D5FF;">平安大桥为你架</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#CC33E5;">健康长寿永不老</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#CC33E5;">美好道路为你铺</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#FFE500;">幸福生活甜蜜蜜</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#FFE500;">吉祥云朵为你飘</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#9933E5;">好运常伴福临门</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#9933E5;">真挚祝福为你发</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#9933E5;">情谊永存常祝愿</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224192356_748.gif" title="20180224192356_748.gif" alt="20180224192356_748.gif" /><br />
</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#FF9900;">长寿日，祝福到</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#FF9900;">幸福短信响不停</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#00D5FF;">祝你快乐健康行</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#00D5FF;">健康人生走不停</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#EE33EE;">身体健康福运到</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#EE33EE;">福如东海取不尽</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#009900;">寿福绵长绕身边</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#009900;">愿你家旺人旺财</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#009900;">生活温馨永健康</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224192458_140.gif" title="20180224192458_140.gif" alt="20180224192458_140.gif" /></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#FFE500;">亲爱的朋友</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#FFE500;">在这百年难遇的一天</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#60D978;">打开的是吉祥</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#60D978;">看到得失鸿运</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#337FE5;">愿所有期望和祝福涌向您</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#337FE5;">祈望您心情舒畅万事顺意</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#E53333;">把这份祝福寿传递</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#E53333;">幸福生活在身边</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span><br />
</span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224192610_103.gif" title="20180224192610_103.gif" alt="20180224192610_103.gif" /><br />
</span> </span></span> 
</p>
<p>
	<br />
</p>
<p>
	<span style="color:#E53333;font-size:32px;">长寿日</span> 
</p>
<p>
	<span style="color:#009900;font-size:32px;">祝每个收到祝福的人</span> 
</p>
<p>
	<span style="color:#FFE500;font-size:32px;">福寿双全</span> 
</p>
<p>
	<span style="color:#337FE5;font-size:32px;">福寿无疆</span> 
</p>
<p>
	<span style="color:#E56600;font-size:32px;">福寿康宁</span> 
</p>
<p>
	<span style="color:#EE33EE;font-size:32px;">赶紧把祝福送给最关心的人</span> 
</p>
<p>
	<span style="color:#00D5FF;font-size:32px;">让福寿延续</span> 
</p>
<p>
	<span style="color:#CC33E5;font-size:32px;">赠人玫瑰，手游余香</span> 
</p>
<p>
	<span style="color:#E53333;font-size:32px;">收到祝福和送出祝福的人都会</span> 
</p>
<p>
	<span style="color:#E53333;font-size:32px;">福寿绵长！</span> 
</p>
<p>
	<span style="color:#E53333;"><br />
</span> 
</p>
<p>
	<span style="color:#E53333;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193320_708.png" title="20180224193320_708.png" alt="20180224193320_708.png" /><br />
</span> 
</p>
<p>
	<span style="color:#E53333;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193334_968.png" title="20180224193334_968.png" alt="20180224193334_968.png" /><br />
</span> 
</p>
<p>
	<span style="color:#E53333;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193343_853.png" title="20180224193343_853.png" alt="20180224193343_853.png" /><br />
</span> 
</p>
<p>
	<span style="color:#E53333;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193354_232.png" title="20180224193354_232.png" alt="20180224193354_232.png" /><br />
</span> 
</p>
<p>
	<span style="color:#E53333;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193402_301.png" title="20180224193402_301.png" alt="20180224193402_301.png" /><br />
</span> 
</p>
<span></span><br />
<p>
	<br />
</p>
<p>
	<span style="font-size:32px;"><br />
</span> 
</p>
<p>
	<span style="color:#E53333;font-size:32px;"><br />
</span> 
</p>'),array(
            'title' =>'福星高照2',
            'thumb' =>'https://qqwin.shanweifang.com.cn/static/upload/article/20180225092824_173.png',
            "bg"=>"https://file.gesmen.com.cn/bg/12.gif",
            'contnet' =>'<p>
	<img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224191220_613.gif" title="20180224191220_613.gif" alt="20180224191220_613.gif" />
</p>
<p>
	<br />
</p>
<p>
	<span style="font-size:48px;background-color:#FFE500;color:#00D5FF;">抢先送你祝福</span>
</p>
<p>
	<span><span style="font-size:48px;"><br />
</span></span><span style="font-size:48px;color:#FFE500;background-color:#00D5FF;">祝你福寿安康</span>
</p>
<p>
	<span><span style="font-size:48px;"><br />
</span></span>
</p>
<p>
	<span><span style="font-size:48px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224191325_661.gif" title="20180224191325_661.gif" alt="20180224191325_661.gif" /><br />
</span></span>
</p>
<p>
	<br />
</p>
<p>
	<span style="font-size:32px;"></span><span style="font-size:32px;color:#E53333;">福神即将带福气到家</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;color:#FFE500;">你可真的是有好福气</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;color:#EE33EE;">祝你身体健康无病灾</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;color:#337FE5;">福气笼罩年年乐开怀</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;color:#FF9900;">福神已到你家大门口</span><br />
<span style="font-size:32px;"></span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224191433_225.gif" title="20180224191433_225.gif" alt="20180224191433_225.gif" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><span style="color:#E53333;">正南喜神</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#B8D100;">正南财神</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#FFE500;">正东贵神</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#60D978;">排场得意须尽欢</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#337FE5;">杠上开花把把出</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#E53333;">钞票把把往里塞</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#009900;">进门给你大金狗</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#9933E5;">每天起床把你叫</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#00D5FF;">新一年喜事连连</span><br />
<br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224191632_443.gif" title="20180224191632_443.gif" alt="20180224191632_443.gif" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><span style="color:#EE33EE;">相聚都只为</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#FFE500;">酝一杯浓酒</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#00D5FF;">酿流动心思</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#60D978;">在福神的祝福下</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#E56600;">看你迷人的面庞</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#4C33E5;">我只想对朋友说</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#337FE5;">这份祝福，一定收下</span><br />
<br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224191725_997.gif" title="20180224191725_997.gif" alt="20180224191725_997.gif" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#FFE500;color:#E53333;">今天四迎福神到</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;">福神来到你家门</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;">送完福气送运气</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;">让你天天有福气</span><br />
<br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224191819_223.gif" title="20180224191819_223.gif" alt="20180224191819_223.gif" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><span style="color:#CC33E5;">今天福神带着其他三神</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#60D978;">特意来给你送财送福的</span><br />
<br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224191957_702.png" title="20180224191957_702.png" alt="20180224191957_702.png" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224192007_774.png" title="20180224192007_774.png" alt="20180224192007_774.png" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224192023_981.png" title="20180224192023_981.png" alt="20180224192023_981.png" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#EE33EE;color:#FFFFFF;">快快来接福神过新年啦</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#B8D100;color:#FFFFFF;">接的越早的朋友越有福</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;">愿你18年好运笑口常开</span></span>
</p>
<p>
	<span style="font-size:32px;"><br />
<span style="background-color:#337FE5;color:#FFFFFF;">把这份祝福送给好便宜</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#E53333;color:#FFFFFF;">越早送出你的福气越多</span><br />
<br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224192311_319.gif" title="20180224192311_319.gif" alt="20180224192311_319.gif" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>'
        ),
        array(
            'title' => '阖家幸福',
            'thumb' =>'https://qqwin.shanweifang.com.cn/static/upload/article/20180225092521_412.png',
            'bg' => ' https://file.gesmen.com.cn/bg/8.gif',
            'contnet' => '<p>
	<img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193438_721.png" title="20180224193438_721.png" alt="20180224193438_721.png" /> 
</p>
<p>
	<br />
</p>
<p>
	<span style="font-size:32px;color:#00D5FF;background-color:#FFE500;"><strong>祝福<span style="color:#E53333;">所有的朋友：</span></strong></span> 
</p>
<p>
	<span><span style="font-size:48px;"><br />
</span></span><span style="font-size:32px;color:#E53333;"><strong>20<span style="color:#FFE500;">18</span></strong></span> 
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;color:#009900;"><strong>一帆<span style="color:#FFE500;">风顺</span></strong></span> 
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;color:#337FE5;"><strong>百种<span style="color:#FF9900;">如意</span></strong></span> 
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;color:#EE33EE;"><strong>千分<span style="color:#60D978;">顺心</span></strong></span> 
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;color:#FF9900;"><strong>完事<span style="color:#337FE5;">如意</span></strong></span><br />
<span style="font-size:32px;"></span> 
</p>
<p>
	<span style="font-size:32px;color:#FF9900;"><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193553_200.gif" title="20180224193553_200.gif" alt="20180224193553_200.gif" /><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#009900;"><strong>首先祝福<span style="color:#9933E5;">问声好，</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#00D5FF;"><strong>亲切<span style="color:#CC33E5;">问候少不了。</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#EE33EE;"><strong>思念多<span style="color:#60D978;">，微信少。</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#FF9900;"><strong>平日<span style="color:#4C33E5;">只是怕你吵，</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#E53333;"><strong>祝你<span style="color:#60D978;">幸福乐逍遥。</span></strong></span><br />
<br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193715_476.gif" title="20180224193715_476.gif" alt="20180224193715_476.gif" /><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#00D5FF;"><strong><span style="color:#337FE5;">一祝你</span><span style="color:#60D978;">身体健康</span>没病闹</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#9933E5;"><strong><span style="color:#FFE500;">二祝你</span>事业顺心<span style="color:#E53333;">赚钱多</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#99BB00;"><strong><span style="color:#EE33EE;">三祝你</span>家庭美满<span style="color:#FF9900;">笑常在</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#E53333;"><strong><span style="color:#FFE500;">四祝你</span>心情愉快<span style="color:#337FE5;">没烦恼</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#60D978;"><strong><span style="color:#9933E5;">五祝你</span>事事如意<span style="color:#FF9900;">事事好</span></strong></span><br />
<br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193800_944.gif" title="20180224193800_944.gif" alt="20180224193800_944.gif" /><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#FFE500;color:#00D5FF;"><strong>生命中有你们，<span style="background-color:#FFE500;color:#E53333;">感觉姿彩</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#FFE500;background-color:#60D978;"><strong>回忆中有你们，<span style="background-color:#EE33EE;">感觉温馨</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><span style="color:#B8D100;"><span style="color:#00D5FF;"></span></span><br />
</span><span style="color:#FFFFFF;background-color:#009900;"><strong>旅途中有你们<span style="color:#FFE500;">，感觉骄傲</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#FFE500;background-color:#E53333;"><strong>失落中有你们<span style="color:#B8D100;">，感觉坚毅</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;"><strong>沉默中有你们<span style="color:#9933E5;">，感觉幸福</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#60D978;background-color:#FFE500;"><strong>真挚的向所有<span style="color:#337FE5;">微信群里好友</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#FFFFFF;background-color:#EE33EE;"><strong>说一句<span style="color:#FFE500;">感谢，</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#FFE500;background-color:#CC33E5;"><strong>我将继续与<span style="color:#FFFFFF;">你们一起前行</span></strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FF9900;color:#FFE500;"><strong>让<span style="color:#E53333;">2018</span>充满<span style="color:#337FE5;">更加美丽的期待</span></strong></span><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#FF9900;color:#FFE500;"><br />
</span></span> 
</p>
<div>
	<br />
</div>
<img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224193953_659.gif" title="20180224193953_659.gif" alt="20180224193953_659.gif" /><br />
<p>
	<br />
</p>
<p>
	<br />
</p>
<p>
	<span style="font-size:32px;"><span style="color:#EE33EE;"><strong>相遇皆缘分，</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#006600;"><strong>认识皆朋友，</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#9933E5;"><strong>感谢大家，</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#FF9900;"><strong>一路相伴所走过的日子，</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#E53333;"><strong>我心存感恩，为你祈祷：</strong></span><br />
<br />
<span style="color:#4C33E5;"><strong>一生交好运，两人结同心</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#FFE500;"><strong>三言两语真，四肢暖意深</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#009900;"><strong>五味没有苦，六神也有主</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#CC33E5;"><strong>七分情常在，八面进财源</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="color:#00D5FF;"><strong>久久不离分，十全更是美</strong></span><br />
<br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224194118_273.gif" title="20180224194118_273.gif" alt="20180224194118_273.gif" /><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#FFE500;color:#E53333;"><strong>愿你每一天</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;"><strong>美丽动人，魅力无限。</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;"><strong>心想事成，万事如意。</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;"><strong>幸福多多，快乐加倍。</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;"><strong>吉祥好运，福寿安康。</strong></span><br />
<br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224194146_705.gif" title="20180224194146_705.gif" alt="20180224194146_705.gif" /><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#FFE500;color:#00D5FF;"><strong>要祝福你在新的一年里：</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;"><strong>事业有看头，</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#00D5FF;"><strong>经济有来头。</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#00D5FF;color:#00D5FF;"><span style="background-color:#FFE500;color:#E53333;"><strong>生活又奔头，</strong></span><span style="color:#E53333;background-color:#FFE500;"></span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#00D5FF;color:#00D5FF;"><span style="background-color:#FFE500;"><strong>喝酒不上头。</strong></span><span style="background-color:#FFE500;"></span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;"><strong>做事不摇头，</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#00D5FF;"><strong>做人不低头。</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#E53333;"><strong>总之事事都对头，</strong></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#00D5FF;"><strong>事事不用愁。</strong></span><br />
<span style="background-color:#00D5FF;color:#00D5FF;"></span><br />
</span> 
</p>
<p>
	<span style="font-size:32px;"><span style="color:#00D5FF;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224194256_456.gif" title="20180224194256_456.gif" alt="20180224194256_456.gif" /><br />
</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#00D5FF;color:#00D5FF;"><br />
</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#00D5FF;color:#00D5FF;"><span style="color:#E53333;"></span><span style="color:#FFFFFF;"><strong>朋友，<span style="color:#9933E5;">我愿意</span></strong></span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#00D5FF;"><span><br />
</span><span style="color:#FFE500;"><strong>把这份真诚的<span style="color:#CC33E5;">祝福送给你</span></strong></span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#00D5FF;"><span><br />
</span><span style="color:#FFFFFF;"><strong>因为我<span style="color:#99BB00;">真心的，</span></strong></span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#00D5FF;"><span><br />
</span><span style="color:#FFE500;"><strong>希望你<span style="color:#E53333;">幸福快乐，</span></strong></span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#00D5FF;"><span><br />
</span><span style="color:#FFFFFF;"><strong>我愿意把<span style="color:#CC33E5;">这份祝福传递，</span></strong></span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#00D5FF;"><span><br />
</span><span style="color:#FFE500;"><strong>愿意我<span style="color:#E53333;">身边的人都幸福，</span></strong></span></span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#00D5FF;"><span><br />
</span><span style="color:#FFFFFF;"><strong>让美好的祝福围绕<span style="color:#FFE500;">在我们身边。</span></strong></span><br />
<span style="color:#64451D;"></span><br />
</span></span> 
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#00D5FF;"><span style="color:#64451D;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224194539_823.gif" title="20180224194539_823.gif" alt="20180224194539_823.gif" /><br />
</span></span></span> 
</p>'),
        array(
            'title' =>'祈愿得福',
            'thumb' => 'https://qqwin.shanweifang.com.cn/static/upload/article/20180225092422_670.png',
            'bg' => 'https://file.gesmen.com.cn/bg/7.gif',
            'contnet' => '<p>
	<img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224195016_292.png" title="20180224195016_292.png" alt="20180224195016_292.png" />
</p>
<p>
	<br />
</p>
<p>
	<span style="font-size:32px;background-color:#E53333;color:#FFFFFF;">送上美好祝愿，快来接收</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#009900;color:#FFFFFF;">家庭祥和，身体健康</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#60D978;color:#FFFFFF;">事业成功，钱财旺旺</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#FFE500;color:#FFFFFF;">好运来到，心情舒畅</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#EE33EE;color:#FFFFFF;">爱情甜蜜，生活吉祥</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#FF9900;color:#FFFFFF;">万事顺利，友情长久</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#00D5FF;color:#FFFFFF;">愿你2018年幸福快乐</span><br />
</p>
<p>
	<img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224195137_119.gif" title="20180224195137_119.gif" alt="20180224195137_119.gif" />
</p>
<p>
	<br />
</p>
<p>
	<span style="font-size:32px;background-color:#FFE500;color:#FFFFFF;">在美好的许愿节里</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#E53333;color:#FFFFFF;">祝愿你亲爱的朋友</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#009900;color:#FFFFFF;">全家和和睦睦</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#EE33EE;color:#FFFFFF;">一生快快乐乐</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#337FE5;color:#FFFFFF;">一世平平安安</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#FF9900;color:#FFFFFF;">天天心情愉悦</span>
</p>
<p>
	<span><span style="font-size:32px;"><br />
</span></span><span style="font-size:32px;background-color:#60D978;color:#FFFFFF;">岁岁喜气洋洋</span><br />
<span style="font-size:32px;"></span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224195236_807.gif" title="20180224195236_807.gif" alt="20180224195236_807.gif" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#99BB00;color:#FFFFFF;">健康是最上佳的礼物</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#EE33EE;color:#FFFFFF;">知足是最巨大的财富</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#64451D;color:#FFFFFF;">信心是最美好的品德</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#E53333;color:#FFFFFF;">关心是最真挚的问候</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#9933E5;color:#FFFFFF;">牵挂是最无私的祝愿</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#60D978;color:#FFFFFF;">在关爱中让友情更深</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#B8D100;color:#FFFFFF;">在牵挂中拉近朋友们</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FF9900;color:#FFFFFF;">愿朋友2018年喜洋洋</span><br />
<br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224195538_814.gif" title="20180224195538_814.gif" alt="20180224195538_814.gif" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#FF9900;color:#FFFFFF;">问候看一看，幸福为你转</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#00D5FF;color:#FFFFFF;">信息读一读，快乐你做主</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#CC33E5;color:#FFFFFF;">微信发一发，钞票任你花</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#FFFFFF;">祝福传一传，好运永做伴</span><br />
<br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224195624_817.gif" title="20180224195624_817.gif" alt="20180224195624_817.gif" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><span style="background-color:#9933E5;color:#FFFFFF;">最后送上一组祈福灯，</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#60D978;color:#FFFFFF;">祝福圈里亲爱的朋友，</span></span>
</p>
<p>
	<span style="font-size:32px;"><span><br />
</span><span style="background-color:#FFE500;color:#FFFFFF;">许愿节快乐又能吉祥！</span><br />
<br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224195942_902.jpg" title="20180224195942_902.jpg" alt="20180224195942_902.jpg" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224195951_489.jpg" title="20180224195951_489.jpg" alt="20180224195951_489.jpg" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224200000_406.jpg" title="20180224200000_406.jpg" alt="20180224200000_406.jpg" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224200012_188.jpg" title="20180224200012_188.jpg" alt="20180224200012_188.jpg" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224200023_866.jpg" title="20180224200023_866.jpg" alt="20180224200023_866.jpg" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224200034_457.jpg" title="20180224200034_457.jpg" alt="20180224200034_457.jpg" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><img src="https://qqwin.shanweifang.com.cn/static/upload/article/20180224200044_240.jpg" title="20180224200044_240.jpg" alt="20180224200044_240.jpg" /><br />
</span>
</p>
<p>
	<span style="font-size:32px;"><br />
</span>
</p>'
        )
    );
    return $list;
}